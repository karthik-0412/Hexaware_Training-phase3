import React, { useState } from 'react';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Button } from 'primereact/button';

export default function RestaurantProfileSettings() {
  const [profile, setProfile] = useState({
    name: 'Restaurant Manager',
    email: 'restaurant@hotbyte.com',
    phone: '+1234567891',
    hours: '9:00 AM - 11:00 PM',
    address: '',
    description: 'Authentic Indian cuisine with modern twist',
    deliveryRadius: '10',
    minOrderAmount: '15',
    totalOrders: 1248,
    averageRating: 4.5,
    monthlyRevenue: 18450
  });

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    alert('Changes saved locally!');
    console.log(profile);
  };

  return (
    <div style={{ padding: '40px', maxWidth: '1000px', margin: '0 auto' }}>
      <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '10px' }}>Restaurant Profile</h2>
      <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '20px' }}>
        Manage your restaurant information and settings
      </p>

      <div style={{
        backgroundColor: '#ffffff',
        padding: '24px',
        borderRadius: '16px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
      }}>
        {/* Form fields */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
          <div style={{ flex: '1 1 45%' }}>
            <label style={labelStyle}>Restaurant Name</label>
            <InputText name="name" value={profile.name} onChange={handleChange} style={inputStyle} />
          </div>
          <div style={{ flex: '1 1 45%' }}>
            <label style={labelStyle}>Email Address</label>
            <InputText name="email" value={profile.email} onChange={handleChange} style={inputStyle} />
          </div>
          <div style={{ flex: '1 1 45%' }}>
            <label style={labelStyle}>Phone Number</label>
            <InputText name="phone" value={profile.phone} onChange={handleChange} style={inputStyle} />
          </div>
          <div style={{ flex: '1 1 45%' }}>
            <label style={labelStyle}>Opening Hours</label>
            <InputText name="hours" value={profile.hours} onChange={handleChange} style={inputStyle} />
          </div>
        </div>

        <div style={{ marginTop: '20px' }}>
          <label style={labelStyle}>Restaurant Address</label>
          <InputTextarea
            name="address"
            value={profile.address}
            onChange={handleChange}
            rows={2}
            autoResize
            style={textareaStyle}
          />
        </div>

        <div style={{ marginTop: '20px' }}>
          <label style={labelStyle}>Restaurant Description</label>
          <InputTextarea
            name="description"
            value={profile.description}
            onChange={handleChange}
            rows={3}
            autoResize
            style={textareaStyle}
          />
        </div>

        {/* Delivery Settings */}
        <div style={{ marginTop: '30px' }}>
          <h4 style={{ fontWeight: '600', fontSize: '16px', marginBottom: '10px' }}>Delivery Settings</h4>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
            <div style={{ flex: '1 1 45%' }}>
              <label style={labelStyle}>Delivery Radius (km)</label>
              <InputText name="deliveryRadius" value={profile.deliveryRadius} onChange={handleChange} style={inputStyle} />
            </div>
            <div style={{ flex: '1 1 45%' }}>
              <label style={labelStyle}>Minimum Order Amount ($)</label>
              <InputText name="minOrderAmount" value={profile.minOrderAmount} onChange={handleChange} style={inputStyle} />
            </div>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '30px', gap: '10px', flexWrap: 'wrap' }}>
          <div style={statBoxStyle}>
            <div style={statLabelStyle}>Total Orders</div>
            <div style={statValueStyle}>{profile.totalOrders.toLocaleString()}</div>
          </div>
          <div style={statBoxStyle}>
            <div style={statLabelStyle}>Average Rating</div>
            <div style={statValueStyle}>{profile.averageRating}</div>
          </div>
          <div style={statBoxStyle}>
            <div style={statLabelStyle}>Monthly Revenue</div>
            <div style={statValueStyle}>${profile.monthlyRevenue.toLocaleString()}</div>
          </div>
        </div>

        {/* Save Button */}
        <div style={{ textAlign: 'right', marginTop: '30px' }}>
          <Button label="Save Changes" icon="pi pi-check" className="p-button-sm p-button-success" onClick={handleSave} />
        </div>
      </div>
    </div>
  );
}

// Inline style constants
const labelStyle = {
  fontSize: '14px',
  fontWeight: '500',
  marginBottom: '6px',
  display: 'block'
};

const inputStyle = {
  width: '100%'
};

const textareaStyle = {
  width: '100%',
  resize: 'vertical'
};

const statBoxStyle = {
  backgroundColor: '#f3f4f6',
  borderRadius: '12px',
  padding: '16px',
  flex: '1 1 30%',
  textAlign: 'center',
  minWidth: '150px'
};

const statLabelStyle = {
  fontSize: '14px',
  color: '#6b7280'
};

const statValueStyle = {
  fontSize: '18px',
  fontWeight: '600',
  marginTop: '4px'
};
