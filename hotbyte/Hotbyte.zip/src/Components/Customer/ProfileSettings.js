import React, { useState } from "react";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Button } from "primereact/button";
import { InputSwitch } from "primereact/inputswitch";
import { Avatar } from "primereact/avatar";
import { Divider } from "primereact/divider";
import { InputIcon } from "primereact/inputtext";
import { Calendar } from 'primereact/calendar';
import { InputTextarea } from 'primereact/inputtextarea';


export default function ProfileSettings() {
  const [gender, setGender] = useState(null);
  const [dob, setDob] = useState(null);
  const genders = [
    { label: "Male", value: "Male" },
    { label: "Female", value: "Female" },
    { label: "Other", value: "Other" },
  ];

  const [notifications, setNotifications] = useState([
  {
    key: "email",
    label: "Email Notifications",
    description: "Receive email notifications about order updates",
    enabled: true,
  },
  {
    key: "sms",
    label: "SMS Notifications",
    description: "Receive SMS notifications for order status",
    enabled: true,
  },
  {
    key: "promotional",
    label: "Promotional Emails",
    description: "Receive promotional emails and special offers",
    enabled: false,
  },
  {
    key: "orderUpdates",
    label: "Order Updates",
    description: "Get notified about order confirmations and delivery updates",
    enabled: true,
  },
]);


  const toggleNotification = (key) => {
  setNotifications((prev) =>
    prev.map((notif) =>
      notif.key === key ? { ...notif, enabled: !notif.enabled } : notif
    )
  );
};


  return (
    <div style={{ maxWidth: "700px", margin: "10px auto", fontFamily: "sans-serif" }}>
      <h2>Profile Settings</h2>

      <div style={{ background: "#ff5722", color: "white", padding: "20px", borderRadius: "8px", marginBottom: "20px", display: "flex", alignItems: "center", gap: "20px" }}>
        <Avatar label="KA" size="xlarge" shape="circle" style={{ backgroundColor: "#ffffff33", color: "white" }} />
        <div>
          <h3 style={{ margin: 0 }}>Customer User</h3>
          <p style={{ margin: 0 }}>tstarkishantkashyap@gmail.com</p>
          <p style={{ margin: 0 }}>Customer Account</p>
        </div>
      </div>

      <Divider />

      <h4>Personal Information</h4>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "20px" }}>
        <span>
          <label>Full Name</label>
          <InputText placeholder="Customer User" style={{ width: "100%" }} />
        </span>
        <span>
          <label>Email Address</label>
          <InputText placeholder="tstarkishantkashyap@gmail.com" style={{ width: "100%" }} />
        </span>
        <span>
          <label>Phone Number</label>
          <InputText placeholder="+1234567890" style={{ width: "100%" }} />
        </span>
        <span>
          <label>Gender</label>
          <Dropdown
            value={gender}
            options={genders}
            onChange={(e) => setGender(e.value)}
            placeholder="Select Gender"
            style={{ width: "100%" }}
          />
        </span>
        <span>
  <label>Date of Birth</label>
  <Calendar
    value={dob}
    onChange={(e) => setDob(e.value)}
    placeholder="dd/mm/yyyy"
    dateFormat="dd/mm/yy"
    showIcon
    style={{ width: "100%" }}
  />
</span>
        <span>
          <label>Emergency Contact</label>
          <InputText placeholder="Emergency contact number" style={{ width: "100%" }} />
        </span>
      </div>

      <Divider />

      <h4>Address Information</h4>
<InputTextarea
  placeholder="123 Main St, City, State 12345"
  rows={3}
  style={{ width: "100%", marginBottom: "20px" }}
/>

      <Divider />

      <h4>Dietary Preferences & Allergies</h4>
<div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "20px" }}>
  <span>
    <label>Dietary Preferences</label>
    <InputTextarea
      placeholder="e.g., Vegetarian, Vegan, Keto, etc."
      rows={3}
      style={{ width: "100%" }}
    />
  </span>
  <span>
    <label>Allergies</label>
    <InputTextarea
      placeholder="e.g., Nuts, Dairy, Gluten, etc."
      rows={3}
      style={{ width: "100%" }}
    />
  </span>
</div>


      <Divider />

      <h4>Account Statistics</h4>
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginBottom: "20px" }}>
        <div style={{ flex: 1, background: "#ff5722", color: "white", padding: "10px", borderRadius: "8px", textAlign: "center" }}>
          <p>Total Orders</p>
          <h2>24</h2>
        </div>
        <div style={{ flex: 1, background: "#4caf50", color: "white", padding: "10px", borderRadius: "8px", textAlign: "center" }}>
          <p>Total Spend</p>
          <h2>₹486.50</h2>
        </div>
        <div style={{ flex: 1, background: "#e91e63", color: "white", padding: "10px", borderRadius: "8px", textAlign: "center" }}>
          <p>Favorite Cuisine</p>
          <h2>Indian</h2>
        </div>
        <div style={{ flex: 1, background: "#673ab7", color: "white", padding: "10px", borderRadius: "8px", textAlign: "center" }}>
          <p>Member Since</p>
          <h2>2025</h2>
        </div>
      </div>

      <Divider />
<h4>Notification Preferences</h4>
<div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
  {notifications.map((notif) => (
    <div
      key={notif.key}
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        background: "#fff",
        border: "1px solid #e0e0e0",
        borderRadius: "8px",
        padding: "15px",
      }}
    >
      <div>
        <p style={{ margin: "0 0 5px 0", fontWeight: "bold" }}>{notif.label}</p>
        <p style={{ margin: 0, color: "#555", fontSize: "0.9em" }}>
          {notif.description}
        </p>
      </div>
      <InputSwitch
        checked={notif.enabled}
        onChange={() => toggleNotification(notif.key)}
      />
    </div>
  ))}
</div>

      <Divider />

      <h4>Security</h4>
      <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
        <Button label="Change Password" />
        {/* <Button label="Enable Two-Factor Authentication" /> */}
      </div>

      <Button
  label="Save Changes"
  style={{ background: "#ff5722", border: "none", width: "100%" }}
  onClick={() => {
    // Example save function
    console.log("Saved preferences:", notifications);
    alert("Changes saved successfully!");
  }}
/>

    </div>
  );
}

